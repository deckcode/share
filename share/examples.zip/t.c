#include <stdio.h>   
#include <sys/socket.h>   
#include <netinet/in.h>   
#include <arpa/inet.h>   
#include <string.h>   
 #include<netdb.h>

 #define NIPQUAD(addr) \
 ((unsigned char *)&addr)[0],  ((unsigned char *)&addr)[1],  ((unsigned char *)&addr)[2],  ((unsigned char *)&addr)[3]


int main()   
{   
	struct in_addr addr1,addr2,addr3;   
	ulong l1,l2,l3,l4,l5;
	
	l1= inet_addr("4.3.2.255"); 
    int s = inet_aton("4.3.2.255",&addr3);

    printf("inet_aton : %d,%x\n",s,addr3.s_addr);
    for (int i = 0; i < 4; i++) {
	int c = addr3.s_addr & 0xFF;
	addr3.s_addr= addr3.s_addr >> 8;
	printf("%d  ",c); 
	}

printf("\n------\n");
    printf("inet_addr : %x\n",l1);

	l3 =l1; 
  for (int i = 0; i < 4; i++) {
	int c = l3 & 0xFF;
	l3 = l3 >> 8;
	printf("%d  ",c); 
	}

    printf("\n------\n");

    l4 = ntohl(l1);
	ulong l8 = ntohl(l4);

	
	printf("l4: %x\n",l4); 
		printf("%x\n",l8);
    for (int i = 0; i < 4; i++) {
	int c = l4 & 0xFF;
	l4 = l4 >> 8;
	printf("%d  ",c); 
	}

	

printf("\n------\n");

    l5 = htonl(l1);
	printf("%x\n",l5); 





	l2 = inet_addr("211.100.21.179");  

	memcpy(&addr1, &l1, 4);   
	memcpy(&addr2, &l2, 4);   
    printf("%ld : %ld\n",l1, l2);
    printf("%ld : %s\n", addr1, &addr2);
	printf("%s : %s\n", inet_ntoa(addr1), inet_ntoa(addr2)); //注意这一句的运行结果   
    printf("%s : %s\n", inet_ntoa(addr2), inet_ntoa(addr1)); //注意这一句的运行结果   
	printf("%s\n", inet_ntoa(addr1));   
	printf("%s\n", inet_ntoa(addr2));  

	printf("%d\n",gethostbyname("www.baidu.com"));
  
    struct hostent *host =  gethostbyname("127.0.0.1");

    // host =  (struct hostent *)gethostbyname("www.baidu.com");
    printf("%d,%s,%s,%s\n",host->h_addrtype,host->h_name,host->h_aliases[0],host->h_addr_list[0]); ;
      struct in_addr asd;
	 asd.s_addr = ntohl((ulong)host->h_addr_list[0]);
     char det[32];
	 char det2[32];
     char det3[32];
	char det4[32];
    
	printf("ipv4- %s\n",inet_ntop(AF_INET,&asd,det,INET_ADDRSTRLEN));
    printf("ipv4- %s\n",inet_ntop(AF_INET,&asd.s_addr,det2,INET_ADDRSTRLEN));
	printf("ipv4- %s\n",inet_ntop(AF_INET,&(asd.s_addr),det3,INET_ADDRSTRLEN));
	printf("ipv4- %s\n",inet_ntop(AF_INET,&((&asd)->s_addr),det4,INET_ADDRSTRLEN));


	 printf("%x\n",asd.s_addr);

    char* str =  inet_ntoa(asd);
    printf("%s--------------------\n",str);

	printf("1  %d\n",host->h_addr);
    printf("2  %s\n",inet_ntoa(*(struct in_addr*)(host->h_addr)));
	printf("3  %s\n",host->h_addr);
	printf("4 %d  %d %d %d \n",host->h_addr[0],host->h_addr[1],host->h_addr[2],host->h_addr[3]);
    

	




	return 0;   
}   
