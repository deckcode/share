#include <arpa/inet.h>  
#include<stdio.h>
#include<stdlib.h>

int main(){

    const char * service = "time";
    printf("%s\n",service);
    printf("%d\n",atoi(service));

    printf("%d\n",htons((unsigned short)atoi(service)));

     const char * service2 = "localhost";
    printf("%s\n",service2);
    printf("%d\n",atoi(service2));0

    printf("%d\n",htons((unsigned short)atoi(service2)));

    return 0;

}


